package Manage;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author User
 */
public class Worker {
    protected String id;
    protected String name;
    protected int age;
    protected int salary;
    protected String wLocation;

    public Worker() {
    }

    public Worker(String id, String name, int age, int salary, String wlocation) {
        this.id = id;
        this.name = name;
        this.age = age;
        this.salary = salary;
        this.wLocation = wLocation;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public int getSalary() {
        return salary;
    }

    public void setSalary(int salary) {
        this.salary = salary;
    }

    public String getWlocation() {
        return wLocation;
    }

    public void setWlocation(String wLocation) {
        this.wLocation = wLocation;
    }

    
}
