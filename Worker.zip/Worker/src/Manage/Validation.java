package Manage;


import java.util.Scanner;
import java.util.ArrayList;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author User
 */
public class Validation {
    private final static Scanner sc = new Scanner(System.in);
    
    public static int checkMinMax(int min, int max)
    {
        while(true)
        {
            try{
                int result = Integer.parseInt(sc.nextLine().trim());
                if(result < min || result > max)
                {
                    throw new NumberFormatException();
                }else{
                    return result;
                }
            }catch(NumberFormatException r)
            {
                System.err.println("Invalid!");
                System.out.print("Enter Again:");
                
            }
        }
    }
    
    public static String checkInputString()
    {
        while(true)
        {
            String result = sc.nextLine().trim();
            if(result.isEmpty())
            {
                System.err.println("Not Empty!");
                System.out.print("Enter Again:");
            }else{
                return result;
            }
        }
    }
    
    public static int checkInputSalaryAndAge()
    {
        while(true)
        {
            try{
                int result = Integer.parseInt(sc.nextLine().trim());
                if(result < 0)
                {
                    throw new NumberFormatException();
                }else{
                    return result;
                }
            }catch(NumberFormatException r)
            {
                System.err.println("Invalid!");
                System.out.print("Enter Again:");  
            }
        }
    }
    
    
    public static boolean checkIdExist(ArrayList<Worker> lworker, String id)
    {
        for(Worker worker : lworker)
        {
           if(id.equalsIgnoreCase(worker.getId()))
           {
               return true;
           }
        }
        return false;
    }
     public static boolean checkWorkerExist(ArrayList<Worker> lWorker, String id,
            String name, int age, int salary, String workLocation) {
        //check from first to last list worker exist or not
        for (Worker worker : lWorker) {
            if (id.equalsIgnoreCase(worker.getId())
                    && name.equalsIgnoreCase(worker.getName())
                    && age == worker.getAge()
                    && salary == worker.getSalary()) {
                return false;
            }
        }
        return true;
    }
}
