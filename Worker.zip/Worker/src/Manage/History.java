package Manage;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author User
 */
public class History extends Worker implements Comparable<History>{
    protected String status;
    protected String date;

    public History() {
    }

    public History(String status, String date, String id, String name, int age, int salary, String wlocation) {
        super(id, name, age, salary, wlocation);
        this.status = status;
        this.date = date;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public int getSalary() {
        return salary;
    }

    public void setSalary(int salary) {
        this.salary = salary;
    }

    public String getwLocation() {
        return wLocation;
    }

    public void setwLocation(String wLocation) {
        this.wLocation = wLocation;
    }
    
    
    
    
    @Override
    public int compareTo(History t)
    {
        return t.getId().compareTo(this.id);
    }
    
}
