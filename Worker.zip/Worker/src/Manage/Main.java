package Manage;


import Manage.Manager;
import java.util.ArrayList;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author User
 */
public class Main {
    public static void main(String[] args) {
        ArrayList<Worker> lWorker = new ArrayList<>();
        ArrayList<History> lHistory = new ArrayList<>();
        while(true)
        {
            int choice = Manager.menu();
            switch(choice)
            {
                case 1 : Manager.addWorker(lWorker);
                break;
            }
        }
        
        
    }
}
