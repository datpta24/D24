/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Manage;


import java.util.ArrayList;


/**
 *
 * @author User
 */
public class Manager {
    public static int menu()
    {
        System.out.println("========== Worker Management ==========");
        System.out.println("1. Add Worker");
        System.out.println("2. Up salary");
        System.out.println("3. Down Salary");
        System.out.println("4. Display Information salary");
        System.out.println("5. Exit");
        System.out.print("Enter Choice:");
        int choice = Validation.checkMinMax(1, 5);
        return choice;
    }
    
    
    //add Worker
    public static void addWorker(ArrayList<Worker> lWorker)
    {
       System.out.print("Enter Code:");
       String id =  Validation.checkInputString();
       System.out.print("Enter Name:");
       String name = Validation.checkInputString();
       System.out.print("Enter Age:");
       int age = Validation.checkInputSalaryAndAge();
       System.out.print("Enter Salary:");
       int salary = Validation.checkInputSalaryAndAge();
       System.out.print("Enter Work Location:");
       String wLocation = Validation.checkInputString();
       if(!Validation.checkWorkerExist( lWorker, id,
             name,  age, salary,  wLocation))
       {
           System.out.println("Worker has already exist");
           
       }else{
           lWorker.add(new Worker(id, name, age, salary,  wLocation) );
           System.out.println("Add successfull");
       }
       
    }

}
